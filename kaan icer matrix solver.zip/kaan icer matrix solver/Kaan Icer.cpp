#include<iostream>
#include<fstream>
#include<string>
#include<new>
using namespace std;

double absolute_value(double p){ // this function returns the absolute value of a number.
	if(p<0){
		p=(-1)*p;
	}
	else{
		p=p;
	}
	return p;
}

int MaxElementInColumn(double **array1, int k, int n){ // this function returns the row number in which row the max. abs. 
	int maxrow=n;									   //value element exists for the desired column after desired row.
	double b;
	for(int j=0; j<k; j++){
		if(j==n){
			b=array1[0][j];
			for(int i=j; i<k; i++){
				if(absolute_value(array1[n][j])<absolute_value(array1[i][j])){
					array1[0][j]=array1[i][j];
					maxrow=i;
				}
			}
			array1[0][j]=b;
		}
	
	}
	return maxrow;
}

int main(){ 		//THE MAIN FUNCTION
	
	ifstream mymatrixfile; //to read the matrix file, I wrote ifstream (A for Ax=b).
	ifstream myBfile; //to read the vector file, I wrote ifstream (b for Ax=b).
	
	string matrixfile, vectorfile; //these are for inputs which are the names of files(string).
	cout<<"write the name of the file of matrix A: ";
	cin>>matrixfile; //takes the name of matrix file(for instance "mymatrix.txt") (A for Ax=b).
	cout<<"write the name of the file of vector b: ";
	cin>>vectorfile; //takes the name of vector file(for instance "myvector.txt") (b for Ax=b).
	
	double **array1, *b, *x, **one_dim_array, one_number, **array2; //**array1 is "A", *b is "b", *x is "x" for Ax=b...
																	//**one_dim_array is extra row vector for row exchange operation...
																	//and one_number is extra number for exchanging the elements od "b" while row exchange.
	int size=0, m=0, a; //"size" is the size of the matrix (A for Ax=b) which is n*n...
						//"m" is a number which is used for row exchange operation...
						//and "a" is the location (row number) for row exchange.
	
	int do_the_operations_matrix=0, do_the_operations_vector=0;//if the files can be opened, these values will be 1 and the function will operate.
	
	string line;
	mymatrixfile.open(matrixfile.c_str()); //here I open the file of matrix and evaluate the size of the n*n matrix by passing the lines.
	if(mymatrixfile.is_open()){
	while(getline(mymatrixfile, line)){
		size++;
	}
	mymatrixfile.close();
	do_the_operations_matrix=1;
	}
	else{
		cout<<"unable to open matrix file."<<endl;
	}
	
	array1= new double* [size]; //dynamic allocation of matrix (A for Ax=b).
	for(int i=0; i<size; i++){
		array1[i]= new double [size];
		}
		
	one_dim_array= new double* [size]; //dynamic allocation of a one dim. matrix which is used for row exchange.
	for(int i=0; i<1; i++){
		one_dim_array[i]= new double[size];
	}
	
	array2= new double*[2]; //dynamic allocation of 2*2 matrix which is used for inverse of 2*2 matrix to find condition number.
	for(int i=0; i<2; i++){
		array2[i]=new double[2];
	}
	
	b= new double[size]; //dynamic allocation of vector (b for Ax=b).
	
	x= new double[size]; //dynamic allocation of solution vector (x for Ax=b).
	
	double number;
	mymatrixfile.open(matrixfile.c_str()); //here I open the matrix file to read the matrix (A for Ax=b)...
	int k=0, f=0;						   //to put the elements of the matrix into an array properly, I used while loop... 
	if(mymatrixfile.is_open()){			   //while loop takes the elements of the matrix until the last element of the file...
	while(mymatrixfile>>number){		   //array1 becomes the matrix (A for Ax=b).
		array1[k][f]=number;
		while(f==size-1){
			f=-1;
			k++;
		}
		f++;
	}
	mymatrixfile.close();
	}
	
	int z=0;
	double number2;
	myBfile.open(vectorfile.c_str()); //here I open the vector file to read the vector (b for Ax=b)...
	if(myBfile.is_open()){			  //to put the elements of the vector into an array vector properly, I used while loop...
	while(myBfile>>number2){		  //while loop takes the elements of the vector until the last element of the file...
		b[z]=number2;				  //b becomes the vector (b for Ax=b).
		z++;	
	}
	myBfile.close();
	do_the_operations_vector=1;
	}
	else{
		cout<<"unable to open vector file."<<endl;
	}
	
	if(size==2){ //if the size of the matrix (A for Ax=b) is 2, this part evaluates the condition number at 1 and infinity.
		if((array1[0][0]*array1[1][1])-(array1[0][1]*array1[1][0])!=0){ //if determinant of the matrix (a for Ax=b) is not zero, this part evaluates the...
																		//max abs. row and column sums of the matrix and inverse matrix to find condition...
																		//number at 1 and infinity.
			double norm_at_1, norm_at_inf, inverse_norm_at_1, inverse_norm_at_inf;
			if((absolute_value(array1[0][0])+absolute_value(array1[1][0]))<(absolute_value(array1[0][1])+absolute_value(array1[1][1]))){
				norm_at_1=absolute_value(array1[0][1])+absolute_value(array1[1][1]);
			}
			else{
				norm_at_1=absolute_value(array1[0][0])+absolute_value(array1[1][0]);
			}
			if((absolute_value(array1[0][0])+absolute_value(array1[0][1]))<(absolute_value(array1[1][0])+absolute_value(array1[1][1]))){
				norm_at_inf=absolute_value(array1[1][0])+absolute_value(array1[1][1]);
			}
			else{
				norm_at_inf=absolute_value(array1[0][0])+absolute_value(array1[0][1]);
			}
			
			double determinant= ((array1[0][0]*array1[1][1])-(array1[0][1]*array1[1][0])); //this part evaluates the inverse matrix(2*2).
			array2[0][0]=array1[1][1]/determinant;
			array2[1][1]=array1[0][0]/determinant;
			array2[0][1]=((-1)*array1[0][1])/determinant;
			array2[1][0]=((-1)*array1[1][0])/determinant;
			
			if((absolute_value(array2[0][0])+absolute_value(array2[1][0]))<(absolute_value(array2[0][1])+absolute_value(array2[1][1]))){
				inverse_norm_at_1=absolute_value(array2[0][1])+absolute_value(array2[1][1]);
			}
			else{
				inverse_norm_at_1=absolute_value(array2[0][0])+absolute_value(array2[1][0]);
			}
			if((absolute_value(array2[0][0])+absolute_value(array2[0][1]))<(absolute_value(array2[1][0])+absolute_value(array2[1][1]))){
				inverse_norm_at_inf=absolute_value(array2[1][0])+absolute_value(array2[1][1]);
			}
			else{
				inverse_norm_at_inf=absolute_value(array2[0][0])+absolute_value(array2[0][1]);
			}
		    double cond_at_1, cond_at_inf; //condition number at 1 and condition number at infinity.
			cond_at_1=norm_at_1*inverse_norm_at_1;
			cond_at_inf=norm_at_inf*inverse_norm_at_inf;
			cout<<"Condition number at 1 is: "<<cond_at_1<<endl;
			cout<<"Condition number at infinity is: "<<cond_at_inf<<endl;
		}
		else{ //when determinant of matrix is zero, it means matrix is singular and the condition number is infinity.
			cout<<"Condition number at both 1 and infinity is: infinity"<<endl;
		}
		
	}
	if(do_the_operations_matrix&&do_the_operations_vector==1){ //these values are 1 when the files are opened.
		for(int j=0; j<size; j++){
			a=MaxElementInColumn(array1, size, m); //it is the function to find the location of max. abs. valued element for partial pivoting .			
			for(int t=0; t<size; t++){ //this part is for row exchange by using the number "a" (row number of max. abs. valued element).
				one_dim_array[0][t]=array1[m][t];
				array1[m][t]=array1[a][t];
				array1[a][t]=one_dim_array[0][t];		
			}
				one_number=b[m]; //when the rows are exchanged, the elements of vectors should be exchanged too.
				b[m]=b[a];
				b[a]=one_number;
			for(int i=m+1; i<size; i++){ //this part is for basic row operations to get upper triangular matrix.
				double d=(array1[i][m]/array1[m][m]);
				for(int n=0; n<size; n++){
					array1[i][n]=array1[i][n]-d*array1[m][n];
				}
				b[i]=b[i]-d*b[m];
			}		
			m++;
		}
		
		int singularity_check=0;
		for(int j=0; j<size; j++){ //this part is for detecting the singularity, for diagonal elements the machine precision are considered.
			if(array1[j][j]<0.00001 && array1[j][j]>-0.00001){
				cout<<"matrix is singular";
				singularity_check=1;
			}
		}
		if(singularity_check==0){ //this part is for finding solution vector (x for Ax=b) for nonsingular matrix.
			for(int j=size-1; j>-1; j--){ //this loop makes back substitution.
				x[j]=b[j]/array1[j][j];
				for(int i=0; i<j; i++){
					b[i]=b[i]-(array1[i][j]*x[j]);
				}
			}
		
			ofstream myoutputfile; //I wrote "ofstream" to create a file called "x" in which file the solutions are written.
			myoutputfile.open("x.txt");
			for(int i=0; i<size; i++){
				myoutputfile<<x[i]<<endl;
				cout<<x[i]<<endl;
			}
			myoutputfile.close();
		}
	}	
	
	for(int i=0; i<size; i++){ //I deleted the array1 (A for Ax=b) to avoid memory loss.
		delete [] array1[i];	
    }
    delete[]array1;
    
    for(int i=0; i<1; i++){ //I deleted the one_dim_array (which is used for row exchange) to avoid memory loss.
		delete [] one_dim_array[i];	
    }
    delete[]one_dim_array;
    
    for(int i=0; i<2; i++){ //I deleted the array2 (2*2 matrix) to avoid memory loss.
    	delete [] array2[i];
	}
	delete[]array2; 
	
	delete[]b; //I deleted the b (b for Ax=b) to avoid memory loss.
	
	delete[]x; //I deleted the x (x for Ax=b) to avoid memory loss.
	
	return 0;

}
